package com.databricks.manager;

import org.junit.Test;
import static org.junit.Assert.assertTrue;

/**
 * This suite should test basic functionality of ResourceManagerImpl implementation.
 */
public class ResourceManagerImplTest {

    @Test
    public void sampleTest() {
        assertTrue(true);
    }
}
